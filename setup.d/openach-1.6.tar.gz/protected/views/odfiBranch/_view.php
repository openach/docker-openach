<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('odfi_branch_id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->odfi_branch_id), array('view', 'id'=>$data->odfi_branch_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('odfi_branch_datetime')); ?>:</b>
	<?php echo CHtml::encode($data->odfi_branch_datetime); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('odfi_branch_originator_id')); ?>:</b>
	<?php echo CHtml::encode($data->odfi_branch_originator_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('odfi_branch_friendly_name')); ?>:</b>
	<?php echo CHtml::encode($data->odfi_branch_friendly_name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('odfi_branch_name')); ?>:</b>
	<?php echo CHtml::encode($data->odfi_branch_name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('odfi_branch_city')); ?>:</b>
	<?php echo CHtml::encode($data->odfi_branch_city); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('odfi_branch_state_province')); ?>:</b>
	<?php echo CHtml::encode($data->odfi_branch_state_province); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('odfi_branch_country_code')); ?>:</b>
	<?php echo CHtml::encode($data->odfi_branch_country_code); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('odfi_branch_dfi_id')); ?>:</b>
	<?php echo CHtml::encode($data->odfi_branch_dfi_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('odfi_branch_dfi_id_qualifier')); ?>:</b>
	<?php echo CHtml::encode($data->odfi_branch_dfi_id_qualifier); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('odfi_branch_go_dfi_id')); ?>:</b>
	<?php echo CHtml::encode($data->odfi_branch_go_dfi_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('odfi_branch_status')); ?>:</b>
	<?php echo CHtml::encode($data->odfi_branch_status); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('odfi_branch_plugin')); ?>:</b>
	<?php echo CHtml::encode($data->odfi_branch_plugin); ?>
	<br />

	*/ ?>

</div>