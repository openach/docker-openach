$( document ).bind( "mobileinit", function(){

});

