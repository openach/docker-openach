<?php
/*********************************************************************************
 * OpenACH is an ACH payment processing platform
 * Copyright (C) 2011 Steven Brendtro, ALL RIGHTS RESERVED
 * 
 * Refer to /legal/license.txt for license information, or view the full license
 * online at http://openach.com/community/license.txt
 ********************************************************************************/

/**
 * PluginCommand class file.
 *
 * @author Steven Brendtro <steven.brendtro@gmail.com>
 * @link http://www.openach.com/
 * @copyright Copyright &copy; 2011 Imagine Solutions, Ltd
 * @license http://www.openach.com/license/
 */

class BankPluginCommand extends CConsoleCommand
{

	public function actionRegister( $class )
	{
		Yii::import( 'application.vendors.OpenACH.nacha.Banks.*' );
		$odfiBranch = OdfiBranch::model();
		$pluginConfig = new $class( $odfiBranch );
		$pluginConfig->register();
		Yii::app()->end();
	}

	public function actionLoad( $odfi_branch_id )
	{
		if ( ! $odfiBranch = OdfiBranch::model()->findByPk( $odfi_branch_id ) )
		{
			throw new Exception( 'Unable to find ODFI Branch ' . $odfi_branch_id );
		}

		$config = $odfiBranch->getBankConfig();

		if ( ! $config )
		{
			throw new Exception( 'Unable to load config.' );
		}

		foreach ( $config->getTransferConfig() as $key => $value )
		{
			echo $key . ":\t" . $value . PHP_EOL;
		}

		Yii::app()->end();

	}

	public function actionTest( $odfi_branch_id )
	{
		if ( ! $odfiBranch = OdfiBranch::model()->findByPk( $odfi_branch_id ) )
		{
			throw new Exception( 'Unable to find ODFI Branch ' . $odfi_branch_id );
		}

		$config = $odfiBranch->getBankConfig();

		if ( ! $config )
		{
			throw new Exception( 'Unable to load config.' );
		}

		$client = OATransferAgent::factory( $config );

		$client->test();

		echo 'Successfully connected to the ODFI Branch using ' . get_class( $client ) . PHP_EOL;

		Yii::app()->end();
	}


}
