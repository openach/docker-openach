<h2><?=$errorTitle;?></h2>
<p><?=$errorMessage;?></p>
<a href="index.html" data-role="button" data-rel="back">Cancel</a> 

