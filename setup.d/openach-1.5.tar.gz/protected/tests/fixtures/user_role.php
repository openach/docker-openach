<?php
/*********************************************************************************
 * OpenACH is an ACH payment processing platform
 * Copyright (C) 2011 Steven Brendtro, ALL RIGHTS RESERVED
 * 
 * Refer to /legal/license.txt for license information, or view the full license
 * online at http://openach.com/community/license.txt
 ********************************************************************************/

return array(
'UserRole_1' => array(
	'user_role_user_id' =>'7b7e2a20-b78b-11e0-b684-00163e4c6b77',
	'user_role_role_id' =>'dd8705ae-b798-11e0-b684-00163e4c6b77',
),
'UserRole_2' => array(
	'user_role_user_id' =>'e3c90b32-b799-11e0-b684-00163e4c6b77',
	'user_role_role_id' =>'e145441c-b798-11e0-b684-00163e4c6b77',
),
'UserRole_3' => array(
	'user_role_user_id' =>'f0383de8-b799-11e0-b684-00163e4c6b77',
	'user_role_role_id' =>'ea513212-b798-11e0-b684-00163e4c6b77',
),
);
