Glyphish Icon Library License Notes

The Glyphish Pro icon libary included here has been purchased by and licensed to OpenACH for use in this project.  Use and/or distribution of the icons in the Glyphish Pro library outside of OpenACH is prohibted by the Glyphish license.  If you would like to use these icons for your own project, please support them by purchasing a license from Glyphish.com.

Sincerely,
OpenACH Staff
